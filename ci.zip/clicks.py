import tls_client, bs4, re, urllib.parse, builtins, asyncio, json, argparse, sys
parser = argparse.ArgumentParser()
parser.add_argument('password')

async def comicalclicks(origin):
    client = tls_client.Session()
    login = urllib.parse.parse_qs(urllib.parse.urlparse(client.post(origin, params={'view':'login', 'action':'login'}, data={'form_user':'chaowenguo', 'form_pwd':parser.parse_args().password}).url).query)
    for _ in ('click', 'ptra'):
        for href in bs4.BeautifulSoup(client.get(origin, params={'view':'account', 'ac':_, 'sid':login.get('sid')[0], 'sid2':login.get('sid2')[0], 'siduid':login.get('siduid')[0]}).text, 'lxml').find_all('a', attrs={'href':re.compile('^gpt\.php')}):
            if not builtins.any(cheat in href.contents for cheat in ("Che@t-link D'ont Click Or You L0se M0ney", "Ché@t Link D'ont Cl1ck T'his 0r Y0u L0se Mo...")):
                entry = urllib.parse.urljoin(origin, href.get('href') if builtins.dict(urllib.parse.parse_qsl(urllib.parse.urlparse(href.get('href')).query)).get('v') == 'entry' else re.search("(?<=location.href=')[.?=&\w]+(?=')", bs4.BeautifulSoup(client.get(urllib.parse.urljoin(origin, href.get('href'))).text, 'lxml').find('script').string).group(0)) 
                entryHtml = bs4.BeautifulSoup(client.get(entry).text, 'lxml')
                while (cheatFrame := entryHtml.find('frame', attrs={'name':'surfmainframe', 'src':re.compile('^gpt\.php')})): 
                    cheat = urllib.parse.urljoin(origin, cheatFrame.get('src'))
                    cheatHtml = bs4.BeautifulSoup(client.get(cheat, headers={'referer':entry}).text, 'lxml')
                    select = cheatHtml.find_all('tt')[1]
                    prompt = f"""<dictionary>{builtins.dict(builtins.zip((_.get('value') for _ in select.find_all('input')), select.stripped_strings))}</dictionary> The dictionary is a mapping of keys to values. Keys are on the left side of colon, values are one the right side of colon. 
                                 <question>{cheatHtml.find('b', attrs={'style':'color: darkred'}).string}</question>
                                 1: Find out the values in <dictionary>.
                                 2: Show steps to work out solution to <question>. If the question is 'The name of this site is...', answer Comical-clicks.
                                 3: Choose the values in step 1 that best match your solution. If the <question> can not be answered, choose the value that contains (YES). Print out the value.
                                 4: Find out the key in <dictionary> corresponded to the value in step 3. Print out the key in format xml <answer> tag like <answer>key</answer>"""
                    print(prompt)
                    llama = tls_client.Session()
                    llama.timeout_seconds = 2 * llama.timeout_seconds
                    llama.post(llama.post('https://huggingface.co/chat/login', headers={'accept':'text/html', 'referer':'https://huggingface.co/chat', 'content-type':'application/x-www-form-urlencoded'}).url, data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password})
                    conversationId = llama.post('https://huggingface.co/chat/conversation', json={'model':'mistralai/Mixtral-8x7B-Instruct-v0.1','preprompt':' '}).json().get('conversationId')
                    data = llama.get(f'https://huggingface.co/chat/conversation/{conversationId}/__data.json', params={'x-sveltekit-invalidated':'11'}).json().get('nodes')[1].get('data')
                    while not (answer := re.search('(?<="text":").+(?="})', llama.post(f'https://huggingface.co/chat/conversation/{conversationId}', json={'inputs':prompt,'id':data[data[data[data[0].get('messages')][0]].get('id')],'is_retry':False,'is_continue':False,'web_search':False,'files':[]}).text)): pass
                    answer = answer.group()
                    print(answer, bs4.BeautifulSoup(answer, 'lxml').find_all('answer')[-1].string)
                    client.post(urllib.parse.urljoin(origin, cheatHtml.find('form').get('action')), headers={'referer':cheat}, data={'q_answer':bs4.BeautifulSoup(answer, 'lxml').find_all('answer')[-1].string})
                    entryHtml = bs4.BeautifulSoup(client.get(entry).text, 'lxml')
                timer = bs4.BeautifulSoup(client.get(urllib.parse.urljoin(origin, entryHtml.find('frame', attrs={'name':'surftopframe'}).get('src')), headers={'referer':entry}).text, 'lxml')
                node = await asyncio.create_subprocess_exec('node', stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE)
                javascript = json.loads((await node.communicate(timer.find('script', string=re.compile('id')).string.encode() + b'console.log(globalThis.JSON.stringify({id,timer,type,key,pretime}))'))[0])
                buttonClicked = builtins.next(index for index,value in builtins.enumerate(img.get('src') for img in timer.find('div', attrs={'id':'buttons'}).find_all('img')) if javascript.get('key') in value)
                await asyncio.sleep(builtins.int(javascript.get('timer')) + 5)
                client.get(urllib.parse.urljoin(origin, 'gpt.php'), params={'v':'verify', 'buttonClicked':buttonClicked, 'id':javascript.get('id'), 'type':javascript.get('type'), 'pretime':javascript.get('pretime'), 'sid':login.get('sid')[0], 'sid2':login.get('sid2')[0], 'siduid':login.get('siduid')[0]}, allow_redirects=False)
                print(bs4.BeautifulSoup(client.get(origin, params={'view':'account', 'ac':'profile', 'sid':login.get('sid')[0], 'sid2':login.get('sid2')[0], 'siduid':login.get('siduid')[0]}).text, 'lxml').find('td', string="Balance: ").find_next_sibling('td').string)

async def main():
    await asyncio.gather(*(sys.modules[__name__].comicalclicks(_) for _ in ('https://comicalclicks.com', 'https://wherethemoneygrows.info')))

asyncio.run(main())