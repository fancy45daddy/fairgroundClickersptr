import asyncio, bs4, argparse, re, builtins, locale, sys, tls_client, urllib.parse
parser = argparse.ArgumentParser()
parser.add_argument('password')
locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

def check(html):
    return builtins.any(html.find(string=re.compile(_)) for _ in ('Invalid paid mail ID.', 'You have already visited this sponsor and', 'Invalid paid mail ID - Ad Has Expired', 'Sorry, this link just expired', 'Just made \$0.000200 Cash for showing you this page'))

async def pathnames(client, pathnames):
    hostname = pathnames[0].split('/')[2]
    for pathname in pathnames:
        flag = False
        while True:
            page = client.get(pathname)
            pas = [_.get('href') for _ in bs4.BeautifulSoup(page.text, 'lxml').find_all('a', attrs={'href':re.compile('/scripts/runner\.php\?PA=')}) if not builtins.any(cheat in _.find('img').get('src') for cheat in ('cheatlink', 'ISYDoNotClick',  'nono.gif', 'Banner%20Do%20Not%20Click'))]
            if flag or not pas: break
            for _ in pas:
                pa = client.get(_)
                paHtml = None
                urlparse = urllib.parse.urlparse(pa.url)
                if 'adminmsg' in urlparse.path:
                    query = builtins.dict(urllib.parse.parse_qsl(urlparse.query))
                    adminmsg = client.get(urllib.parse.urlunparse(urlparse._replace(query='&'.join(f'{key}={value}' for key,value in (query | {'requested':urllib.parse.quote(query.pop('redirect')), 'start':'0', 'submit':'Continue'}).items()))))
                    paHtml = bs4.BeautifulSoup(adminmsg.text, 'lxml')
                else: paHtml = bs4.BeautifulSoup(pa.text, 'lxml')
                if paHtml.find('img', attrs={'src':'http://my-ptr.com/pages/botdetect_top.gif'}) or paHtml.find('img', attrs={'src':'http://www.yourptrclub.com/pages/botdetect_top.gif'}): paHtml = bs4.BeautifulSoup(client.post(_, data={'q':paHtml.find('input', attrs={'name':'q'}).get('value'), 'a':'1', 'submit':'Continue >>'}).text, 'lxml')
                for keLink in paHtml.find_all('a', attrs={'href':re.compile('/scripts/runner\.php\?KE=')}):
                    print(pathname, keLink)
                    ke = client.get(f'http://{hostname}{keLink.get("href")}')
                    print(ke.url)
                    keHtml = bs4.BeautifulSoup(ke.text, 'lxml')
                    if flag := sys.modules['__main__'].check(keHtml):
                        fr = None
                        break
                    elif (frTag := keHtml.find('frame', attrs={'src':re.compile('FR')})):
                        fr = frTag.get('src')
                        break
                else:
                    if flag := sys.modules['__main__'].check(paHtml):continue
                    fr = None
                    try:
                        fr = paHtml.find('frame', attrs={'src':re.compile('FR')}).get('src')
                    except:
                        print(pathname, paHtml)
                        sys.exit(0)
                if fr is None: continue
                await asyncio.sleep(builtins.int(re.search('(?<=\s)\d+(?=\s+seconds)', bs4.BeautifulSoup(client.get(fr).text, 'lxml').find(string=re.compile('seconds'))).group()))
                print(page.url, bs4.BeautifulSoup(client.get(fr).text, 'lxml').find_all(string=re.compile('cash|point', re.I)))

async def fairgroundClickersptr(hostname):
    client = tls_client.Session()
    email = 'chaowen.guo1@gmail.com'
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':email, 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    if hostname == 'clicksmania.net':
        if points := bs4.BeautifulSoup(client.get(f'http://{hostname}/pages/exchanger.php').text, 'lxml').find('th'):
            client.post(f'http://{hostname}/pages/exchanger.php', data={'points':re.search('\d+', points.string).group(0), 'confirm':'exchange now'})
    elif hostname != 'email-moneymaker.com' and hostname != 'preciouspomsptr.com':
        link = enter.find('a', attrs={'href':re.compile('cpconverter')}).get('href')
        cpconverter = bs4.BeautifulSoup(client.get(link).text, 'lxml')
        if (current := builtins.int(locale.atof(cpconverter.find('b', string='Your Total Current Available Points: ').find_next('b').string))) > (min := builtins.int(cpconverter.find('b', string='The Minimum Amount of Points to Convert for your member type is: ').find_next('b').string)):
            min = min if min else 100
            client.post(link, data={'points': (current // min) * min,'msg_mode':'Convert Now'})
    pid =  {'billiondollarmails.com':1, 'fairground-clickersptr.com':2, 'myster-e-mail.com':3, 'roadto51.com':11, 'homesteadmails.com':28, 'payingemails4u.com':1, 'butterfliesnroses.com':3, 'classicalmails.com':1}
    match hostname:
        case 'fairground-clickersptr.com': client.post(f'http://{hostname}/pages/cashout.php', data={'pid':pid.get(hostname), 'accinfo':email, 'reqamount':'2', 'rfullbalance':'1', 'fee':'0', 'net':'2', 'showme':'Yes', 'reqsubmit':'+++++++++++++++Request+++++++++++++++'})
        case 'billiondollarmails.com' | 'payingemails4u.com' | 'classicalmails.com': client.post(f'http://{hostname}/pages/cashout.php', data={'pid':pid.get(hostname), 'accinfo':email, 'reqamount':'3', 'rfullbalance':'1', 'fee':'0', 'net':'3', 'showme':'Yes', 'reqsubmit':'+++++++++++++++Request+++++++++++++++'})           
        case 'butterfliesnroses.com': client.post(f'http://{hostname}/pages/withdraw.php', data={'pid':pid.get(hostname), 'accinfo':email, 'reqamount':'3', 'rfullbalance':'1', 'fee':'0', 'net':'3', 'showme':'Yes', 'reqsubmit':'+++++++++++++++Request+++++++++++++++'})
        case 'roadto51.com' | 'myster-e-mail.com' | 'homesteadmails.com': client.post(f'http://{hostname}/pages/withdraw.php', data={'pid':pid.get(hostname), 'accinfo':email, 'reqamount':'2', 'rfullbalance':'1', 'fee':'0', 'net':'2', 'showme':'Yes', 'reqsubmit':'+++++++++++++++Request+++++++++++++++'})                 
    pathnames = [enter.find('a', string=re.compile(_)).get('href') for _ in ('Cash PTC', 'Tier 1&2 Points', 'Tier 1&2 Cash', 'Points PTC', 'Contest PTC', 'Treasure Room', 'Support Contest PTC')] 
    match hostname:
        case 'fairground-clickersptr.com' | 'classicalmails.com': pathnames += enter.find('a', attrs={'href':re.compile('game\.php$')}).get('href'),
    match hostname:
        case 'email-moneymaker.com': pathnames = [f'pages/{_}' for _ in ('ptc', 'kwikkieptc', 'ptsearch', 'pointcptc', 'serenity')]
        case 'clicksmania.net': pathnames = [f'pages/{_}' for _ in ('treasure', 'ptc_cash_ptc', 'ptsearch1', 'mania', 'tgbtrroom', 'pointcptc', 'ptc-points', 'treasure')]
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('tgbaffmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/(?:page|affiliate)s?/(\w+)\.php\?refid=\\1')}))
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('perptcmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/pages/(\w+)ptc(?:c|p)\.php\?refid=\\1')}))
    await sys.modules['__main__'].pathnames(client, pathnames)

async def wallabymail(hostname):
    client = tls_client.Session()
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    pathnames = [f'http://{hostname}/pages/{_}.php' for _ in ('ptc', 'ptc_contest', 'ptsearch', 'pointptc', 'treasure')]
    match hostname:
        case 'wallabymail.info': pathnames += f'http://{hostname}/pages/friendorfoe.php',
        case 'scubacash.com': pathnames += f'http://{hostname}/pages/aquarium.php',
        case 'wine-n-rosesptr.info': pathnames += f'http://{hostname}/pages/winery.php',
        case 'marinomails.com': pathnames += f'http://{hostname}/pages/watercraft.php',
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('tgbaffmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/(?:page|affiliate)s?/(\w+)\.php\?refid=\\1', re.I)}))
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('perptcmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/pages/(\w+)ptc(?:c|p)\.php\?refid=\\1', re.I)}))
    await sys.modules['__main__'].pathnames(client, pathnames)

async def polarbearclicks(hostname):
    client = tls_client.Session()
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    pathnames = [enter.find('a', string=re.compile(_)).get('href') for _ in ('Tier 1 ?& ?2 PTC', 'Cash PTC', 'Contest PTC', 'Points? PTCS?')]
    match hostname:
        case 'polarbearclicks.com' | 'preciouspomsptr.com' | 'castlemails.info': pathnames += (f'http://{hostname}/pages/{_}.php' for _ in ('game', 'treasure'))
        case 'summerslamgiveaway.com': pathnames += (f'http://{hostname}/pages/{_}.php' for _ in ('tgbtrroom', 'treasure'))
        case 'infofriendptr.com': pathnames += f'http://{hostname}/pages/tgbtrroom.php',
        case 'circlecptr.com': pathnames += (f'http://{hostname}/pages/{_}.php' for _ in ('nativeamerican', 'firstpeopleptc', 'nativeroom'))
        case 'aftermidnightmails.info': pathnames += (f'http://{hostname}/pages/{_}.php' for _ in ('wolfroom', 'usaptc1'))
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('tgbaffmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/(?:page|affiliate)s?/(\w+)\.php\?refid=\\1', re.I)}))
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('perptcmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/pages/(\w+)ptc(?:c|p)\.php\?refid=\\1', re.I)}))
    await sys.modules['__main__'].pathnames(client, pathnames)

async def grammasfriends(hostname):
    client = tls_client.Session()
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    pathnames = [f'http://{hostname}/pages/{_}.php' for _ in ('ptc', 'ptcontest', 'ptsearch', 'treasure')]
    match hostname:
        case 'grammasfriends.com': pathnames += f'http://{hostname}/pages/ptc_point.php',
        case 'showcaseptr.com':
            pathnames = [pathname.replace('ptc', 'ptc_cash') if 'ptc.php' in pathname else pathname for pathname in pathnames]
            pathnames += (f'http://{hostname}/pages/{_}.php' for _ in ('tgbtrroom', 'pointptc'))
        case 'monkeybizs.com': pathnames = [pathname for pathname in pathnames if 'treasure' not in pathname]
    pathnames += (urllib.parse.urljoin(f'http://{hostname}', _.get('href')) for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('sinnyaffmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'class':'fill_div'}))
    pathnames += (urllib.parse.urljoin(f'http://{hostname}', _.get('href')) for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('persoptc\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'class':'fill_div'}))
    await sys.modules['__main__'].pathnames(client, pathnames)

async def yourptrclub(hostname):
    client = tls_client.Session()
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    pathnames = [f'http://{hostname}/pages/{_}.php' for _ in ('ptc', 'ptcontest', 'ptsearch', 'tgbtrroom')]
    pathnames += (_.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('tgbaffmain\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'href':re.compile(f'{hostname}/(?:page|affiliate)s?/(\w+)\.php\?refid=\\1', re.I)}))
    pathnames += (urllib.parse.urljoin(f'http://{hostname}/pages',  _.get('href')) for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('perspagesmenu\.php$')}).get('href')).text, 'lxml').find_all('a', attrs={'target':'_"blanc"', 'href':lambda _: _ != 'advertise2.php'}))
    await sys.modules['__main__'].pathnames(client, pathnames)

'''case 'email-moneymaker.com': pathnames = [f'pages/{_}' for _ in ('ptc', 'kwikkieptc', 'ptsearch', 'pointcptc', 'serenity')]
case 'clicksmania.net': pathnames = [f'pages/{_}' for _ in ('treasure', 'ptc_cash_ptc', 'ptsearch1', 'mania', 'tgbtrroom', 'pointcptc', 'ptc-points')]'''

async def guardianmails(hostname):
    client = tls_client.Session()
    enter = bs4.BeautifulSoup(client.post(f'http://{hostname}/pages/enter.php', data={'username':'chaowen.guo1@gmail.com', 'password':parser.parse_args().password, 'submit':'Login'}).text, 'lxml')
    pathnames = [href for _ in enter.find('font', string='Ways To Earn').find_all_next('a', limit=8) if not (href := _.get('href')).endswith(('inbox.php', 'newsurfer.php', 'ptpmain.php', 'sinnyaffmain.php'))]
    if hostname == 'my-ptr.com': pathnames = [pathname.replace('ptc', 'sub_ptc') if 'ptc.php' in pathname else pathname for pathname in pathnames]
    pathnames += (f'http://{hostname}' + _.get('href') for _ in bs4.BeautifulSoup(client.get(enter.find('a', attrs={'href':re.compile('sinnyaffmain')}).get('href')).text, 'lxml').find_all('a', attrs={'class':'fill_div'}))
    await sys.modules['__main__'].pathnames(client, pathnames)

async def main():
    #await asyncio.gather(*(fairgroundClickersptr(_) for _ in ('billiondollarmails.com', 'fairground-clickersptr.com', 'myster-e-mail.com', 'www.roadto51.com', 'www.homesteadmails.com', 'payingemails4u.com', 'butterfliesnroses.com', 'classicalmails.com', 'email-moneymaker.com', 'clicksmania.net')), *(guardianmails(_) for _ in ('dreammails.net', 'bluerosepost.com', 'hot-rods-ptr.com', 'my-ptr.com')))
    await asyncio.gather(*(fairgroundClickersptr(_) for _ in ('billiondollarmails.com', 'fairground-clickersptr.com', 'myster-e-mail.com', 'roadto51.com', 'homesteadmails.com', 'payingemails4u.com', 'butterfliesnroses.com', 'classicalmails.com')), *(wallabymail(_) for _ in ('wallabymail.info', 'scubacash.com', 'wine-n-rosesptr.info', 'marinomails.com')), *(polarbearclicks(_) for _ in ('polarbearclicks.com', 'aftermidnightmails.info', 'summerslamgiveaway.com', 'preciouspomsptr.com', 'castlemails.info', 'infofriendptr.com', 'circlecptr.com')), guardianmails('my-ptr.com'), *(grammasfriends(_) for _ in ('grammasfriends.com', 'cashemails4u.com', 'cashclickcorner.com', 'catmails.net', 'countryfolksptr.com', 'countrygardenemail.com', 'grammaswhizkids.com', 'magnoliamails.com', 'mailingmania.net', 'monkeybizs.com', 'pandabearemails.net', 'riverfallmails.com', 'showcaseptr.com', 'superdollarsptr.com')), yourptrclub('yourptrclub.com'))

asyncio.run(main())

#import inspect
#x, y, z = 1, 2, 3
#def retrieve_name(var):
#    callers_local_vars = inspect.currentframe().f_back.f_locals.items()
#    return [var_name for var_name, var_val in callers_local_vars if var_val is var]
#print(retrieve_name(y))
#        <frameset framespacing=0 frameborder=1 border=1 rows="100,1*">
#            <frame  marginwidth=0 marginheight=0 name=timerfrm src=http://my-ptr.com/scripts/runner.php?PA=61172&amp;FR=1 scrolling=no>
#            <frame  marginwidth=0 marginheight=0 name=Main src=http://my-ptr.com/scripts/runner.php?REDIRECT=http%3A%2F%2Frosegardenptr.com%2Fpages%2Findex.php%3Frefid%3Dinfinitecreator&amp;hash=f35c15b026be544a1dc6bf05bd883492>
#        </frameset>

#        <noframes>
#            <body>
#            This page uses frames, but your browser does not support them.
#            </body>
#        </noframes>
#        </frameset>
