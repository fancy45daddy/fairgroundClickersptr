sudo apt install -y --no-install-recommends linux-modules-extra-$(uname -r) xvfb anbox gawk lzip adb privoxy ffmpeg
sudo apt purge -y mawk
Xvfb :99 &
DISPLAY=:99 firefox https://d.apkpure.com/b/APK/com.givvyvideos?version=latest &
sudo curl --output-dir /var/lib/anbox -o android.img https://bitbucket.org/chaowenguo/android/raw/main/amd64.img
sudo awk -i inplace /container-manager/{sub\(/$/\,\"\ --use-rootfs-overlay\"\)}1 /usr/lib/systemd/system/anbox-container-manager.service
sudo awk -i inplace /session-manager/{sub\(/$/\,\"\ --single-window\ --window-size=1000\,1024\"\)}1 /usr/lib/systemd/user/anbox-session-manager.service
OPENGAPPS_RELEASEDATE=$(curl https://api.github.com/repos/opengapps/x86_64/releases/latest | awk -F\" /tag_name/{print\$\(NF-1\)})
OPENGAPPS_FILE=open_gapps-x86_64-7.1-pico-$OPENGAPPS_RELEASEDATE.zip
curl -L -O https://sourceforge.net/projects/opengapps/files/x86_64/$OPENGAPPS_RELEASEDATE/$OPENGAPPS_FILE
unzip $OPENGAPPS_FILE Core/*
for filename in Core/*.tar.lz
do
    tar -xf $filename -C Core
done
opengapps=/var/lib/anbox/rootfs-overlay/system/priv-app
sudo mkdir -p $opengapps
sudo cp -r $(find Core -type d -name "PrebuiltGmsCore") $opengapps
sudo cp -r $(find Core -type d -name "GoogleLoginService") $opengapps
sudo cp -r $(find Core -type d -name "Phonesky") $opengapps
sudo cp -r $(find Core -type d -name "GoogleServicesFramework") $opengapps
rm -rf Core $OPENGAPPS_FILE
sudo chown -R 100000:100000 $opengapps/Phonesky $opengapps/GoogleLoginService $opengapps/GoogleServicesFramework $opengapps/PrebuiltGmsCore
ls $opengapps
sudo systemctl start anbox-container-manager
sudo mkdir /dev/binderfs
sudo mount -t binder binder /dev/binderfs
Xvfb :99 &
systemctl --user set-environment DISPLAY=:99
sleep 30
ls /run | awk /anbox-container/
systemctl --user start anbox-session-manager
sleep 30
ps aux | awk /anbox/
adb wait-for-device
shell='sudo lxc-attach -q --clear-env -P /var/lib/anbox/containers -n default -v PATH=/sbin:/system/bin:/system/sbin:/system/xbin -v ANDROID_ASSETS=/assets -v ANDROID_DATA=/data -v ANDROID_ROOT=/system -v ANDROID_STORAGE=/storage -v ASEC_MOUNTPOINT=/mnt/asec -v EXTERNAL_STORAGE=/sdcard --'
while [[ $($shell /system/bin/sh -c getprop\ sys.boot_completed) != 1 ]]
do
    sleep 30
done
adb devices -l
curl -O https://f-droid.org/repo/com.termux_118.apk
adb install com.termux_118.apk
rm -rf com.termux_118.apk
ls -al ~/Downloads/*.apk
pkill -9 -f firefox
mv ~/Downloads/*.apk givvyVideos.apk
adb install givvyVideos.apk
sudo awk -i inplace /listen-address/{sub\(/127.0.0.1/\,\"0.0.0.0\"\)}1 /etc/privoxy/config
echo 'forward-socks5t   /  0.0.0.0:1080 .' | sudo tee -a /etc/privoxy/config
sudo systemctl restart privoxy
ssh -fNT -D 0.0.0.0:1080 -oStrictHostKeyChecking=no -oProxyCommand='ssh -oStrictHostKeyChecking=no -T guest@ssh.devcloud.intel.com' u180599@devcloud
$shell /system/bin/sh <<EOF
am start -n com.termux/com.termux.app.TermuxActivity
sleep 30
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put global http_proxy 192.168.250.1:8118
am force-stop com.termux
EOF
ffmpeg -f x11grab -i :99 givvyVideos.webm &
$shell /data/data/com.termux/files/usr/bin/bash <<EOF
am start -n com.givvyvideos/com.givvyvideos.shared.view.DefaultActivity 
tap()
{
    sleep 30
    sh /system/bin/uiautomator dump /data/local/tmp/ui.xml
    local array=(\$(/data/data/com.termux/files/usr/bin/gawk -vRS=\> -F\" /"\$1"/{gsub\(/[][\,]/\,\"\ \"\,\$\(NF-1\)\)\;print\$\(NF-1\)} /data/local/tmp/ui.xml))
    echo \${array[@]}
    input tap \$((\$((\${array[0]} + \${array[2]})) / 2)) \$((\$((\${array[1]} + \${array[3]})) / 2))
}
tap text=\"English\"
tap resource-id=\"com.givvyvideos:id\\\/saveButton\"
tap resource-id=\"com.givvyvideos:id\\\/btAgree\"
tap resource-id=\"com.givvyvideos:id\\\/googleLogin\"
sleep 30
sh /system/bin/uiautomator dump /data/local/tmp/ui.xml
tap resource-id=\"identifierId\"
input text chaowen.guo1@gmail.com
tap resource-id=\"identifierNext\"
sleep 30
input text $1
tap resource-id=\"passwordNext\"
tap content-desc=\"I\ agree\"
tap text=\"ACCEPT\"
#sleep 1m
#am start -n com.givvyvideos/com.givvyvideos.shared.view.DefaultActivity
#tap resource-id=\"com.givvyvideos:id\\\/closeButton\"
radio=(\$(tap resource-id=\"com.givvyvideos:id\\\/radioImageContainer\" | /data/data/com.termux/files/usr/bin/gawk END{print}))
echo \${radio[@]}
sleep 30
am start -n com.givvyvideos/com.givvyvideos.shared.view.DefaultActivity
watchButton=(\$(tap resource-id=\"com.givvyvideos:id\\\/watchButton\" | /data/data/com.termux/files/usr/bin/gawk END{print}))
echo \${watchButton[@]}
#while true
#do
    input tap \$((\$((\${radio[0]} + \${radio[2]})) / 2)) \$((\$((\${radio[1]} + \${radio[3]})) / 2))
    sleep 30
    am start -n com.givvyvideos/com.givvyvideos.shared.view.DefaultActivity    
    input tap \$((\$((\${watchButton[0]} + \${watchButton[2]})) / 2)) \$((\$((\${watchButton[1]} + \${watchButton[3]})) / 2))
#done
EOF