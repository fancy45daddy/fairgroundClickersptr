open -a Google\ Chrome https://d.apkpure.com/b/APK/com.givvy.shorts?version=latest
echo y | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager system-images\;android-29\;google_apis\;x86_64
brew install gawk privoxy
ls ~/Downloads/*.apk
pkill -9 -f Google
mv ~/Downloads/*.apk givvyShorts.apk
echo no | $ANDROID_HOME/cmdline-tools/latest/bin/avdmanager create avd -f -n android -k system-images\;android-29\;google_apis\;x86_64
gawk -i inplace {sub\(/320/\,\"500\"\)\;sub\(/640/\,\"900\"\)}1 ~/.android/avd/android.avd/config.ini
$ANDROID_HOME/emulator/emulator -avd android -no-window -wipe-data -no-snapshot -no-audio -no-boot-anim -writable-system -memory 4096 -gpu swiftshader_indirect -http-proxy http://127.0.0.1:8118 &
$ANDROID_HOME/platform-tools/adb wait-for-device
$ANDROID_HOME/platform-tools/adb root
while [[ $($ANDROID_HOME/platform-tools/adb exec-out getprop sys.boot_completed) != 1 ]]
do
    sleep 30
done
$ANDROID_HOME/platform-tools/adb shell avbctl disable-verification
$ANDROID_HOME/platform-tools/adb reboot
$ANDROID_HOME/platform-tools/adb wait-for-device
$ANDROID_HOME/platform-tools/adb root
while [[ $($ANDROID_HOME/platform-tools/adb exec-out getprop sys.boot_completed) != 1 ]]
do
    sleep 30
done
$ANDROID_HOME/platform-tools/adb exec-out getprop sys.boot_completed
$ANDROID_HOME/platform-tools/adb remount
$ANDROID_HOME/platform-tools/adb devices -l
curl -O https://f-droid.org/repo/com.termux_118.apk
$ANDROID_HOME/platform-tools/adb install com.termux_118.apk
rm -rf com.termux_118.apk
$ANDROID_HOME/platform-tools/adb shell <<EOF
am start -n com.termux/com.termux.app.TermuxActivity
sleep 90
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
ls /data/data/com.termux/files/usr/bin/
EOF
$ANDROID_HOME/platform-tools/adb install givvyShorts.apk
$ANDROID_HOME/platform-tools/adb pull /system/bin/screenrecord screenrecord
gawk -i inplace -vRS=\\n{10} {printf\"%s\"\,gensub\(/\\xb4\\x00\\x00\\x00/\,\"\\xff\\xff\\xff\\xff\"\,19\)} screenrecord
$ANDROID_HOME/platform-tools/adb push screenrecord /system/bin/screenrecord
echo 'forward-socks5t   /  127.0.0.1:1080 .' >> /usr/local/etc/privoxy/config
/usr/local/opt/privoxy/sbin/privoxy /usr/local/etc/privoxy/config
ssh -fNT -D 1080 -oStrictHostKeyChecking=no -oProxyCommand='ssh -oStrictHostKeyChecking=no -T guest@ssh.devcloud.intel.com' u180599@devcloud
$ANDROID_HOME/platform-tools/adb shell /data/data/com.termux/files/usr/bin/bash <<EOF
pm uninstall --user 0 com.android.chrome
am start -n com.givvy.shorts/com.givvy.shorts.shared.view.DefaultActivity
tap()
{
    sleep 30
    uiautomator dump /data/local/tmp/ui.xml
    local array=(\$(awk -vRS=\> -F\" /"\$1"/{gsub\(/[][\,]/\,\"\ \"\,\$\(NF-1\)\)\;print\$\(NF-1\)} /data/local/tmp/ui.xml))
    echo \${array[@]}
    input tap \$((\$((\${array[0]} + \${array[2]})) / 2)) \$((\$((\${array[1]} + \${array[3]})) / 2))
}
linker64 /system/bin/screenrecord /data/local/tmp/givvyShorts.mp4 &

tap resource-id=\"com.givvy.shorts:id\\\/googleLogin\"
dumpsys activity | awk /mCurrentFocus/
sleep 30
uiautomator dump /data/local/tmp/ui.xml
tap resource-id=\"identifierId\"
dumpsys activity | awk /mCurrentFocus/
input text chaowen.guo1@gmail.com
tap resource-id=\"identifierNext\"
dumpsys activity | awk /mCurrentFocus/
sleep 60
input text $1
tap resource-id=\"passwordNext\"
dumpsys activity | awk /mCurrentFocus/
tap text=\"I\ agree\"
dumpsys activity | awk /mCurrentFocus/
tap text=\"ACCEPT\"
dumpsys activity | awk /mCurrentFocus/
tap text=\"English\"
dumpsys activity | awk /mCurrentFocus/
tap resource-id=\"com.givvy.shorts:id\\\/nextButton\"
dumpsys activity | awk /mCurrentFocus/
wm=(\$(wm size | awk {sub\(/x/\,\"\ \"\,\\\$NF\)\;print\\\$NF}))
while true
do
    sleep 20
    uiautomator dump /data/local/tmp/ui.xml
    if [[ -z \$(awk /text=\"United\ States\"/{print} /data/local/tmp/ui.xml) ]]
    then
        input swipe \$((\${wm[1]} / 2)) \$((\${wm[0]} - 10)) \$((\${wm[1]} / 2)) 0 2000
    else
        break
    fi
done
tap text=\"United\ States\"
tap resource-id=\"com.givvy.shorts:id\\\/nextButton\"
array=(\$(tap resource-id=\"com.givvy.shorts:id\\\/interestTextView\" | awk END{print}))
echo \${array[@]}
for i in {1..4}
do
    input tap \$((\$((\${array[\$((4 * \$i))]} + \${array[\$((\$((4 * \$i)) + 2))]})) / 2)) \$((\$((\${array[\$((\$((4 * \$i)) + 1))]} + \${array[\$((\$((4 * \$i)) + 3))]})) / 2))
done
tap resource-id=\"com.givvy.shorts:id\\\/nextButton\"
tap resource-id=\"com.givvy.shorts:id\\\/secondTab\"
tap resource-id=\"com.givvy.shorts:id\\\/startButton\"
tap resource-id=\"com.givvy.shorts:id\\\/btAgree\"
for out in {0..4}
do
    input swipe \$((\${wm[1]} / 2)) \$((\${wm[0]} - 10)) \$((\${wm[1]} / 2)) 0 2000
done
EOF

cat <<EOF
    sleep 20
    uiautomator dump /data/local/tmp/ui.xml
    array=(\$(awk -vRS=\> -F\" /resource-id=\"com.givvy.shorts:id\\\/slider\"/{gsub\(/[][\,]/\,\"\ \"\,\$\(NF-1\)\)\;print\$\(NF-1\)} /data/local/tmp/ui.xml))
    if [[ \$(dumpsys activity | awk /mCurrentFocus/) == *com.givvy.shorrts/com.applovin.adview.AppLovinFullscreenActivity* ]]
    then
        sleep 40
        uiautomator dump /data/local/tmp/ui.xml
        array=(\$(awk -vRS=\> -F\" /resource-id=\"al_skipButton\"/{gsub\(/[][\,]/\,\"\ \"\,\$\(NF-1\)\)\;print\$\(NF-1\)} /data/local/tmp/ui.xml))
        if [[ \${#array[@]} -ne 0 ]]
        then
            echo \${array[@]}
            input tap \$((\$((\${array[0]} + \${array[2]})) / 2)) \$((\$((\${array[1]} + \${array[3]})) / 2))
            tap resource-id=\"al_closeButton\"
        else
            tap NAF=\"true\"
        fi
    elif [[ \$(dumpsys activity | awk /mCurrentFocus/) != *com.givvy.shorts/com.givvy.shorts.shared.view.DefaultActivity* ]]
    then
        while [[ \$(dumpsys activity | awk /mCurrentFocus/) != *com.givvy.shorts/com.givvy.shorts.shared.view.DefaultActivity* ]]
        do
            input keyevent 4
        done
    elif [[ \${#array[@]} -ne 0 ]]
    then
	    input swipe \$((\${array[0]} + 10)) \$((\$((\${array[1]} + \${array[3]})) / 2)) \${array[2]} \$((\$((\${array[1]} + \${array[3]})) / 2))
    fi
done
EOF
$ANDROID_HOME/platform-tools/adb pull /data/local/tmp/givvyShorts.mp4 givvyShorts.mp4