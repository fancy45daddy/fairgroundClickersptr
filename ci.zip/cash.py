import tls_client, asyncio, bs4, argparse, re, builtins, sys, urllib.parse, json
parser = argparse.ArgumentParser()
parser.add_argument('password')

async def cashmining(origin):
    client = tls_client.Session(force_http1=True)
    client.timeout_seconds = 2 * client.timeout_seconds
    email = 'chaowen.guo1@gmail.com'
    login = client.get(origin)
    if login.status_code !=200: return
    print(bs4.BeautifulSoup(client.post(origin, data={'token':bs4.BeautifulSoup(login.text, 'lxml').find('input', attrs={'name':'token'}).get('value'), 'user':email, 'password':parser.parse_args().password, 'connect':''}).text, 'lxml').find('b', attrs={'id':'c_coins'}).string, client.cookies)
    print(bs4.BeautifulSoup(client.post(origin, params={'page':'withdraw'}, data={'cash':'2.50', 'gateway':'paypal', 'email':email, 'submit':'Request'}).text, 'lxml').find('div', attrs={'role':'alert'}))
    node = await asyncio.create_subprocess_exec('node', stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE)
    javascript = json.loads((await node.communicate(re.sub('.+\$.+', '', bs4.BeautifulSoup(client.get(urllib.parse.urljoin(origin, 'mining.php')).text, 'lxml').find('script', string=re.compile('token')).string).encode() + b'console.log(globalThis.JSON.stringify({secs,token,hash,sid}))'))[0])
    while True:
        await asyncio.sleep(builtins.int(javascript.get('secs')))
        client.post(urllib.parse.urljoin(origin, 'system/ajax.php'), data={'a':'mining', 'data':javascript.get('sid'), 'token':javascript.get('token')})
        print(bs4.BeautifulSoup(client.get(origin).text, 'lxml').find('b', attrs={'id':'c_coins'}).string)
        node = await asyncio.create_subprocess_exec('node', stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE)
        javascript = json.loads((await node.communicate(re.sub('.+\$.+', '', bs4.BeautifulSoup(client.get(urllib.parse.urljoin(origin, 'mining.php'), params={'previous':javascript.get('sid'), 'rand':javascript.get('hash')}).text, 'lxml').find('script', string=re.compile('token')).string).encode() + b'console.log(globalThis.JSON.stringify({secs,token,hash,sid}))'))[0])

async def main():
    await asyncio.gather(*(sys.modules[__name__].cashmining(_) for _ in ('https://cashmining.me', 'http://cashmining.forumforyou.it')), return_exceptions=True)

asyncio.run(main())