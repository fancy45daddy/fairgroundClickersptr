import asyncio, tls_client, bs4, re, builtins, urllib.parse

interval = {1:7, 2:15, 3:30, 4:45}

async def main(user, pub):
    client = tls_client.Session(force_http1=True)
    client.cookies.set('cfx_accid', '444816', domain='.heedyou.com', path='/')
    client.cookies.set('cfx_loginticket', '3062c151b3449705c6a921ad333b500f538dc298e47ee8babaeae1413f0fdd6c686eaa858df5a1851a3f597c9cd52819bdb83edbff9f7ecc', domain='.heedyou.com', path='/')
    for _ in client.get('https://clixwall.com/Application/graphql', json={'query':f'{{getWallAds(ip:"127.0.0.1",user:{user},pub:"{pub}",country:"IN"){{ads{{id\ntype}}}}}}'}).json().get('data').get('getWallAds').get('ads'):
        userClick = client.get('http://clixwall.com/offerwall/user_click.php', params={'i':_.get('id'), 'pub':pub, 'user':user})
        await asyncio.sleep(interval.get(_.get('type')))
        client.get(urllib.parse.urljoin('http://clixwall.com/offerwall/', re.search('verify-click.+?(?=")', bs4.BeautifulSoup(userClick.text, 'lxml').find('script').string).group()))
        #print(bs4.BeautifulSoup(client.get('https://heedyou.com/p/account').text, 'lxml').find('span', attrs={'id':'headercashbalance'}).string)
        
async def gather():
    await asyncio.gather(main(444816, 'fDyznqjEbps'), main('chaowenguo', 'X9CDYI8BKZLSQB5AGM0WRUYQP'), main(728327, 'RW46K-Q3BD0-FE9GZ'))

asyncio.run(main(444816, 'fDyznqjEbps'))