import tls_client, bs4, json, argparse, re, urllib.parse, builtins, sys, asyncio, pathlib, base64, cv2, numpy
parser = argparse.ArgumentParser()
parser.add_argument('password')

def gemini(text, image):
    client = tls_client.Session()
    return client.post('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent', params={'key':'AIzaSyDE0pb3P8eGAlUmj3S1N3te8GnlvXJawns'}, json={'contents':[{'parts':[{'text':text}, {'inline_data':{'mime_type':'image/png', 'data':image}}]}],'generationConfig':{'temperature':0},'safety_settings':[{'category':'HARM_CATEGORY_SEXUALLY_EXPLICIT','threshold':'BLOCK_NONE'},{'category':'HARM_CATEGORY_HATE_SPEECH','threshold':'BLOCK_NONE'},{'category':'HARM_CATEGORY_HARASSMENT','threshold':'BLOCK_NONE'},{'category':'HARM_CATEGORY_DANGEROUS_CONTENT','threshold':'BLOCK_NONE'}]}).json().get('candidates')[0].get('content').get('parts')[0].get('text') 

async def main():
    client = tls_client.Session()
    loginForm = bs4.BeautifulSoup(client.get('https://www.togybux.com/login').text, 'lxml').find('form', attrs={'id':'loginForm'})
    captcha = ''.join(json.loads(sys.modules[__name__].gemini('There are 5 uppercase English letters in the image. What are they? Output in json array', loginForm.find('img', attrs={'id':'captcha_img'}).get('src').split(',')[-1])))
    client.post('https://www.togybux.com/login', data={'a':'submit', 'csrf_token':loginForm.find('input', attrs={'name':'csrf_token'}).get('value'), 'username':'chaowenguo', 'password':parser.parse_args().password, 'captcha':captcha})
    print(bs4.BeautifulSoup(client.get('https://www.togybux.com/account').text, 'lxml').find('strong', string='Balance').find_next('strong').string)
    for _ in bs4.BeautifulSoup(client.get('https://www.togybux.com/view_ads').text, 'lxml').find_all('a', attrs={'class':'text-white'})[8:]:
        html = bs4.BeautifulSoup(client.get(urllib.parse.urljoin('https://www.togybux.com/view_ads/token/', re.search("(?<=openAd\(')\w+(?=',)", _.get('onclick')).group())).text, 'lxml')
        await asyncio.sleep(builtins.int(re.search('(?<=ad_seconds = )\d+(?=;)', html.find('script', string=re.compile('ad_seconds')).string).group()))
        ptcForm = html.find('form', attrs={'id':'ptc_form'})
        pathlib.Path('a.png').write_bytes(base64.b64decode(html.find('img', attrs={'usemap':'#Map'}).get('src').split(',')[-1]))
        img = cv2.imdecode(numpy.frombuffer(base64.b64decode(html.find('img', attrs={'usemap':'#Map'}).get('src').split(',')[-1]), numpy.uint8), 0)
        size = img.shape[0]
        for _ in range(6):
            print(sys.modules[__name__].gemini('''1: Find out what is in each picture?
                                                  2: Whether the picture is upside down? Output in boolean''', base64.b64encode(cv2.imencode('.png', img[:,size * _:size * (_ + 1)])[-1]).decode()))
        print(json.loads(re.search('\[[ ,\w]+\]', sys.modules[__name__].gemini('''There are 6 pictures in the image.
                                                                                  1: What is in the picture?
                                                                                  2: Whether the picture is upside down?
                                                                                  3: Output the answer in step 2 in json array of boolean''', html.find('img', attrs={'usemap':'#Map'}).get('src').split(',')[-1])).group()).index(True))
        index = builtins.int(bs4.BeautifulSoup(sys.modules[__name__].gemini('There are 6 pictures in the image. Which picture is upside down? Output the index starting at 0 in format xml <index> tag', html.find('img', attrs={'usemap':'#Map'}).get('src').split(',')[-1]), 'lxml').find('index').string)
        print(index)
        print(client.post(ptcForm.get('action'), files={'token':ptcForm.find('input', attrs={'name':'token'}).get('value'), 'ad_token':re.search("(?<=ptc_validate\(')\w+(?='\);)", html.find('map').find_all('area')[index].get('onclick')).group(), 'do':'validate'}).text)
        break

asyncio.run(main())
