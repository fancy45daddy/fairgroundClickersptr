import tls_client, bs4, re, asyncio, builtins, asyncssh

async def main():
    #async with asyncssh.connect('devcloud', username='u214193', known_hosts=None, proxy_command='ssh -oStrictHostKeyChecking=no -oServerAliveInterval=60 -T guest@ssh.devcloud.intel.com', keepalive_interval=60) as conn:
        client = tls_client.Session()
        client.timeout_seconds = 5 * client.timeout_seconds
        client.proxies = 'socks5://localhost:1080'   #builtins.str((await conn.forward_socks('localhost', 1080)).get_port())
        print(client.get('https://httpbin.org/ip').json())
        client.cookies.set('AP_Login', '1', domain='timebucks.com', path='/')
        client.cookies.set('AP_Login_E', '1', domain='timebucks.com', path='/')
        client.cookies.set('AP_Force_logout', '1', domain='timebucks.com', path='/')
        client.cookies.set('AP_Username', 'MmtSdkdZODREU0IrNlBPWXBSNEZCN1dDakZHdysvdkMxTDMydEREUWtHQmlUUzYxSXZtRmZPa2htbVFKZXBORDo6RoFZF9SNbDGgoXOpRRpTLg%3D%3D', domain='timebucks.com', path='/')
        dailyPole = client.get('https://timebucks.com/publishers/lib/scripts/php/action.php', params={'action':'getDailyPole'}).json()
        if dailyPole.get('status') == 1:
            pollQuestionID = dailyPole.get('pollQuestionID')
            answerID = builtins.next(builtins.iter(dailyPole.get('poll_options').keys()))
            print(client.post('https://timebucks.com/publishers/lib/scripts/php/action.php', data={'action':'submitDailyPole', 'answerID':answerID, 'pollQuestionID':pollQuestionID}).json().get('msg'))
        while True:
            while not (token := bs4.BeautifulSoup(client.post('https://timebucks.com/publishers/pages/task_tab_templete/view_content_ads.php', data={'userID':'224619265', 'isMObileView':''}).text, 'lxml').find('script', string=re.compile('token'))): pass
            token = re.search("(?<=token: ')\w+(?=')", token.string).group()
            print(client.get('https://timebucks.com/publishers/lib/scripts/php/clicks/UsersAds.php', params={'action':'GetUserAds'}).text)
            while not (UsersAds := builtins.next(builtins.iter(client.get('https://timebucks.com/publishers/lib/scripts/php/clicks/UsersAds.php', params={'action':'GetUserAds'}).json().get('data')), None)): pass
            adID = UsersAds.get('encrypted_ad_id')
            sessionId = client.post('https://timebucks.com/publishers/lib/scripts/php/clicks/Users.php', data={'action':'CheckAdExpiry', 'adID':adID, 'token':token}).json().get('sessionid')
            await asyncio.sleep(builtins.int(UsersAds.get('timer')))
            client.post('https://timebucks.com/publishers/lib/scripts/php/clicks/UsersCredit.php', data={'action':'InsertClicksCredit', 'adID':adID, 'token':token, 'sessionId':sessionId})
            print(client.post('https://timebucks.com/publishers/lib/scripts/php/action_notifications.php', data={'action':'getheaderitems'}).json().get('unpaid_earnings').get('total_wallet'))
            
asyncio.run(main())

#jm8carter@hotmail.com
