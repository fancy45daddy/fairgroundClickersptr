import process from 'process'
import WebSocket from '/usr/share/nodejs/ws/wrapper.mjs'
import * as uuid from '/usr/share/nodejs/uuid/wrapper.mjs'

const accessToken = await globalThis.fetch('https://api.paperspace.io/users/login?' + new globalThis.URLSearchParams({include:'user'}).toString(), {method:'post', headers:{'content-type':'application/json'}, body:globalThis.JSON.stringify({email:'john8bush@outlook.com',password:process.argv.at(2),PS_REQUEST_VALIDATION_KEY:'Nu/CfHRkn2A1YqTQHNfzrWgIJF+iV/0B+QfTXDcya2g='})}).then(_ => _.json()).then(_ => _.id)
const notebookId = await globalThis.fetch('https://api.paperspace.io/notebooks/rbrbjexabgqy820/getNotebook?' + new globalThis.URLSearchParams({namespace:'tygo7u64es', access_token:accessToken}).toString()).then(_ => _.json()).then(_ => _.id)
await globalThis.fetch('https://api.paperspace.io/notebooks/v2/stopNotebook', {method:'post', headers:{'content-type':'application/json'}, body:globalThis.JSON.stringify({access_token:accessToken, notebookId, namespace:'tygo7u64es'})}).then(_ => _.json())
await new globalThis.Promise(_ => globalThis.setTimeout(_, 1000 * 60))
while (true)
{
    const machine = await globalThis.fetch('https://api.paperspace.io/notebooks/v2/startNotebook', {method:'post', headers:{'content-type':'application/json'}, body:globalThis.JSON.stringify({access_token:accessToken,notebookId,vmTypeLabel:'Free-IPU-POD4',teamId:1440565,shutdownTimeout:6,clusterId:'clehbtvty'})})
    if (globalThis.Object.is(machine.status, 429))
    {
        console.log(await machine.json())
	    await new globalThis.Promise(_ => globalThis.setTimeout(_, 1000 * 60))
	    continue
    } 
    else
    {
	    console.log(await machine.status)
	    const {token, fqdn} = await machine.json()
        console.log(fqdn)
	    while (true)
		{
            const pal = await globalThis.fetch(`https://${fqdn}/api/contents/pal.ipynb`, {headers:{authorization:`token ${token}`}})
            if (!globalThis.Object.is(pal.status, 200))
			{
				console.log(pal.status, await pal.text())
				await new globalThis.Promise(_ => globalThis.setTimeout(_, 1000 * 60))
				continue
			}
			else
			{
				const source = await pal.json().then(_ => _.content.cells.at(0).source)
				const session = await globalThis.fetch(`https://${fqdn}/api/sessions`, {method:'post', headers:{authorization:`token ${token}`}, body:globalThis.JSON.stringify({path:'',type:''})})
				const _ = await session.json()
	            const kernel = _.kernel.id, sessionId = _.id
	            console.log(_)
	            const ws = new WebSocket(`wss://${fqdn}/api/kernels/${kernel}/channels?` + new globalThis.URLSearchParams({'session_id':sessionId}).toString(), [], {headers:{cookie:session.headers.get('set-cookie').split(';').at(0)}})
	            ws.onopen = () => ws.send(globalThis.JSON.stringify({buffers:[],channel:'shell',content:{silent:false,store_history:true,user_expressions:{},allow_stdin:true,stop_on_error:true,code:source},header:{date:new globalThis.Date().toISOString(),msg_id:uuid.v1(),msg_type:'execute_request',session:sessionId,username:'',version:'5.2'},metadata:{},parent_header:{}}))
                await new globalThis.Promise(_ => globalThis.setTimeout(_, 1000 * 60 * 2))
	            ws.close()
				break
			}
		}
		break
    }
}