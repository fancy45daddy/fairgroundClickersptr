import * as playwright from 'playwright-chromium'
import path from 'path'
import {promises as fs} from 'fs'
import os from 'os'

globalThis.setTimeout(async () => await context.close(), 1000 * 60 * 300)
const context = await playwright.chromium.launchPersistentContext(await fs.mkdtemp(path.join(os.tmpdir(), 'pal')), {channel:'chrome', args:['--disable-blink-features=AutomationControlled', '--start-maximized'], headless:false, recordVideo:{dir:'videos'}, viewport:null})//default_args https://github.com/microsoft/playwright/blob/5faf6f9e69c2148e94c81675fb636eb31a02b5e7/src%2Fserver%2Fchromium%2Fchromium.ts#L78
const dailymotion = await context.newPage()
context.setDefaultTimeout(0)
await dailymotion.goto('https://www.dailymotion.com/video/x87ytjz')