import asyncio, tls_client, bs4, re, urllib.parse, base64

async def main():
    client = tls_client.Session(force_http1=True)
    client.cookies.set('cfx_accid', '444816', domain='heedyou.com', path='/')
    client.cookies.set('cfx_loginticket', 'd79e5e8a8d91ceecf658661254158cc846ffef61f0e0f675a50b41fd0cf8cfa456966e9a69be188024e9ba0eafd04a5ac80fc8b3906e6066', domain='heedyou.com', path='/')
    for _ in bs4.BeautifulSoup(client.get('https://heedyou.com/p/viewads').text, 'lxml').find_all('a', attrs={'href':re.compile('p/vap\?c'), 'onclick':True}):
        for img in bs4.BeautifulSoup(re.search('.+id="nearcaptext".+', bs4.BeautifulSoup(client.get(urllib.parse.urljoin('http://ads.heedyou.com', _.get('href').replace('vap', 'ptc'))).text, 'lxml').find('script', string=re.compile('id="nearcaptext"')).string).group(), 'lxml').find_all('img'):
            print(base64.b64encode(client.get(urllib.parse.urljoin('http://ads.heedyou.com', img.get('src'))).content).decode())
        break
        
asyncio.run(main())
