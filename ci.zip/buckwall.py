import tls_client, builtins
#async def buck():
#    async with aiohttp.ClientSession(headers={'User-Agent':userAgent}, cookies={'AP_Login':'1', 'AP_Login_E':'1', 'AP_Force_logout':'1', 'AP_Username':'VnhWQnd4eG9GYzh0eCs2QXBYY1FKYk9RQjRNcUJlVTlQZmlGK1UyZmQyYz06OpwsmVc0JDqKHP%2F%2FDaOFP7k%3D'}) as client:
#        async with client.get('https://timebucks.com/publishers/lib/scripts/api/BuyTasksUsers.php', params={'action':'GetMySubmissionsDT', 'filter':-1}) as submission:
#            for _ in (await submission.json(content_type=None)).get('data'):
#                if _.get('1') == '222992737':
#                    async with client.post('https://timebucks.com/publishers/lib/scripts/api/BuyTasksUsers.php', data={'action':'GetInstructions', 'CampaignId':_.get('2'), 'SessionId':_.get('0')}) as instruction:
#                        print(_.get('2'), await instruction.json(content_type=None))
def wall():
    client = tls_client.Session()
    client.timeout_seconds = 5 * client.timeout_seconds
    hash = '8bc6d0531808c012f0cb21a33012172d'
    for i in builtins.range(30):
        submission = client.get('https://timebucks.com/TimewallApi/TasksApi.php', params={'action':'GetMySubmissionsDT', 'Filter':-1, 'start':i * 200, 'length':200, 'Hash':hash})
        for _ in (submission.json()).get('data'):
            if _.get('1') == '223840621':
                instruction = client.post('https://timebucks.com/TimewallApi/TasksApi.php', json={'action':'GetInstructions', 'CampaignId':_.get('2'), 'SessionId':_.get('0'), 'Hash':hash})
                print(instruction.json())
wall()