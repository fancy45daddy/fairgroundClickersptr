import aiohttp, asyncio, itertools, base64, argparse, lxml.etree, urllib.request
parser = argparse.ArgumentParser()
parser.add_argument('azurePipelines')
with urllib.request.urlopen('https://www.useragents.me') as _: userAgent = lxml.etree.parse(_, lxml.etree.HTMLParser()).xpath('//textarea[@class="form-control ua-textarea" and contains(text(), "Linux x86_64")]/text()')[0]

async def main():
    async with aiohttp.ClientSession(headers={'User-Agent':userAgent}) as client:
        async with client.get('https://dev.azure.com/chaowenguo/ci/_apis/build/builds', params={'api-version':'7.0'}) as response:
            for _ in itertools.islice((await response.json()).get('value'), 1, None):
                async with client.delete(f'https://dev.azure.com/chaowenguo/ci/_apis/build/builds/{_.get("id")}', params={'api-version':'7.0'}, headers={'authorization':f'Basic {base64.b64encode((":" + parser.parse_args().azurePipelines).encode()).decode()}'} ) as _: pass

asyncio.run(main())
#curl -u :$2 -H content-type:application/json -d '{}' https://dev.azure.com/chaowenguo/ci/_apis/pipelines/24/runs?api-version=7.0